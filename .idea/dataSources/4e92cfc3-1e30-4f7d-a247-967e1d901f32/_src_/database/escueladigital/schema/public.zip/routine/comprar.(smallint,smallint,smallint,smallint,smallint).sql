create function comprar(_proveedor smallint, _producto smallint, _cantidad smallint, _valor smallint, _usuario smallint) returns smallint
LANGUAGE plpgsql
AS $$
DECLARE
  _idfactura smallint;
BEGIN
  -- SE INSERTA EL REGISTRO DE COMPRAS
  INSERT INTO compras (id_tercero, id_producto, cantidad, valor, id_usuario)
  VALUES (_proveedor, _producto, _cantidad, _valor, _usuario)
  RETURNING id_compra INTO _idfactura;
  IF FOUND THEN
    -- SE ACTUALIZA EL STOCK DEL PRODUCTO
    UPDATE productos
    SET cantidad = cantidad + _cantidad, precio = _valor, id_usuario = _usuario
    WHERE id_producto = _producto;
  ELSE
    RAISE EXCEPTION 'No fue posible insertar el registro de compras';
  END IF;

  RETURN _idfactura;
END;
$$;
