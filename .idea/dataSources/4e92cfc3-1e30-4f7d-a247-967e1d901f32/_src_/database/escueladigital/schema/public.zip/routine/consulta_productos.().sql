create function consulta_productos() returns SETOF productos
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY SELECT id_producto, nombre, cantidad, precio, id_usuario
               FROM productos ORDER BY nombre;
END;
$$;
