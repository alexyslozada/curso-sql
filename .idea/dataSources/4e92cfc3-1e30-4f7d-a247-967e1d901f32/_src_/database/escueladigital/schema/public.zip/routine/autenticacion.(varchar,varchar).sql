create function autenticacion(_usuario character varying, _clave character varying) returns TABLE(id_usuario smallint, nombre character varying, id_perfil smallint, perfil character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY SELECT a.id_usuario, a.nombre, b.id_perfil, b.perfil
               FROM usuarios as a NATURAL JOIN perfiles as b
               WHERE a.usuario = _usuario AND a.clave = md5(_clave);
  IF NOT FOUND THEN
    RAISE EXCEPTION 'El usuario o la contraseña no coinciden';
  END IF;

END;
$$;
