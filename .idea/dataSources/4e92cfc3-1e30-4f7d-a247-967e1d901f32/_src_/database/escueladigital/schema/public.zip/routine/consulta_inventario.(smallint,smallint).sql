create function consulta_inventario(_limite smallint, _pagina smallint) returns SETOF productos
LANGUAGE plpgsql
AS $$
DECLARE
  _inicio smallint;
BEGIN
  _inicio = _limite * _pagina - _limite;
  RETURN QUERY SELECT id_producto, nombre, cantidad, precio, id_usuario
               FROM productos
               ORDER BY id_producto
               LIMIT _limite
               OFFSET _inicio;
END;
$$;
