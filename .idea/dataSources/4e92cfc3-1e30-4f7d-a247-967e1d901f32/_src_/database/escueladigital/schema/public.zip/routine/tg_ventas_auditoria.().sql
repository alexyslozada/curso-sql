create function tg_ventas_auditoria() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO auditoria (id_usuario, accion, tabla, anterior, nuevo)
      SELECT NEW.id_usuario, 'INSERTAR', 'VENTAS', row_to_json(NEW.*), null;
  END IF;
  RETURN NEW;
END;
$$;
