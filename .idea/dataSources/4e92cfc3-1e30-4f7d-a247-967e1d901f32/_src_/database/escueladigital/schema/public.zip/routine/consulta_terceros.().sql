create function consulta_terceros() returns SETOF terceros
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY SELECT id_tercero, identificacion, nombre, direccion, telefono FROM terceros ORDER BY nombre;
END;
$$;
