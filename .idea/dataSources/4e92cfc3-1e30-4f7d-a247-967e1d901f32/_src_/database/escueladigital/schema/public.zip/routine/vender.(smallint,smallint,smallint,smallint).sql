create function vender(_cliente smallint, _producto smallint, _cantidad smallint, _usuario smallint) returns smallint
LANGUAGE plpgsql
AS $$
DECLARE
  _valor smallint;
  _existencia smallint;
  _idfactura smallint;
BEGIN
  -- SE BUSCA EL PRECIO DE VENTA Y SE VALIDA SI HAY STOCK DE VENTAS
  SELECT CAST(precio * 1.3 AS smallint), cantidad
  INTO STRICT _valor, _existencia
  FROM productos
  WHERE id_producto = _producto;

  -- SI HAY SUFICIENTE STOCK, SE VENDE
  IF _existencia >= _cantidad THEN
    -- SE INSERTA EL REGISTRO DE VENTAS
    INSERT INTO ventas (id_tercero, id_producto, cantidad, valor, id_usuario)
    VALUES (_cliente, _producto, _cantidad, _valor, _usuario)
    RETURNING id_venta INTO _idfactura;
    IF FOUND THEN
      -- SE ACTUALIZA EL STOCK DEL PRODUCTO
      UPDATE productos
      SET cantidad = cantidad - _cantidad, id_usuario = _usuario
      WHERE id_producto = _producto;
    ELSE
      RAISE EXCEPTION 'No fue posible insertar el registro de ventas';
    END IF;
  ELSE
    RAISE EXCEPTION 'No existe suficiente cantidad para la venta %', _existencia;
  END IF;

  RETURN _idfactura;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE EXCEPTION 'No se encontró el producto a vender';
END;
$$;
