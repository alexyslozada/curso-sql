create function consulta_ventas(_limite smallint, _pagina smallint) returns TABLE(id_venta smallint, fecha date, cliente character varying, producto character varying, cantidad smallint, valor smallint)
LANGUAGE plpgsql
AS $$
DECLARE
  _inicio smallint;
BEGIN
  _inicio = _limite * _pagina - _limite;

  RETURN QUERY SELECT v.id_venta, v.fecha, t.nombre as proveedor,
                                           p.nombre as producto, v.cantidad, v.valor
               FROM ventas as v INNER JOIN terceros as t
                   ON v.id_tercero = t.id_tercero
                 INNER JOIN productos as p
                   ON v.id_producto = p.id_producto
               LIMIT _limite
               OFFSET _inicio;
END;
$$;
