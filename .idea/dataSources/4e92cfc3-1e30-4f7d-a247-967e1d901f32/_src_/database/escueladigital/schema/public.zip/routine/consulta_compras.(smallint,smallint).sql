create function consulta_compras(_limite smallint, _pagina smallint) returns TABLE(id_compra smallint, fecha date, cliente character varying, producto character varying, cantidad smallint, valor smallint)
LANGUAGE plpgsql
AS $$
DECLARE
  _inicio smallint;
BEGIN
  _inicio = _limite * _pagina - _limite;

  RETURN QUERY SELECT c.id_compra, c.fecha, t.nombre as cliente,
                                            p.nombre as producto, c.cantidad, c.valor
               FROM compras as c INNER JOIN terceros as t
                   ON c.id_tercero = t.id_tercero
                 INNER JOIN productos as p
                   ON c.id_producto = p.id_producto
               LIMIT _limite
               OFFSET _inicio;
END;
$$;
